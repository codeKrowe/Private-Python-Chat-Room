from socket import *
from threading import Thread
import sys
import chilkat
import struct
import pickle
import json
from time import sleep
from AES_Class import *

if (len(sys.argv) < 2):
    print 'Usage: python client.py <port>\n'
    sys.exit(0)
else:
    PORT = int(sys.argv[1])



hashcrypt = chilkat.CkCrypt2()
success = hashcrypt.UnlockComponent("Anything for 30-day trial.")
if (success != True):
    print(hashcrypt.lastErrorText())
    sys.exit()
hashcrypt.put_EncodingMode("hex")
hashcrypt.put_HashAlgorithm("md5")

dhAlice = chilkat.CkDh()
success = dhAlice.UnlockComponent("Anything for 30-day trial")
if (success != True):
    print(dhAlice.lastErrorText())
    sys.exit()


HOST = 'localhost'
BUFSIZE = 1024
ADDR = (HOST, PORT)
client = socket(AF_INET, SOCK_STREAM)
client.connect(ADDR)

inital_setup = client.recv(8)

print "inital_setup", inital_setup

p = client.recv(BUFSIZE)
print " p ", p
g = client.recv(BUFSIZE)
print ""
print " g ", g 
print "here"
g = int(g)

success = dhAlice.SetPG(p,g)
if (success != True):
    print("P is not a safe prime")
    sys.exit()
if (success == True):
    print "success"

eAlice = dhAlice.createE(256)
# client.send(eAlice)


eBob = client.recv(BUFSIZE)


print "size", sys.getsizeof(eAlice)
client.send(eAlice)

print eBob
print type(eBob)



print "eAlice"
print eAlice
# kAlice = dhAlice.findK(eBob)
kAlice = dhAlice.findK(eBob)
print("Alice's shared secret (should be equal to Bob's)")
print(kAlice)

serverKey = None
if inital_setup == "1":
  print "attempt to recv server key"
  serverKey = client.recv(1024)
  print "serverSessionKey", serverKey

sessionkey = hashcrypt.hashStringENC(kAlice)
print "SessionKey", sessionkey


a = AESClass("cbc",128,0,"hex")

#################
# For the moment there is waste execurion and setup
# of a new key
# just doing it this way for testing a breivity 
# when attempting to connect from multiple clients
#

print "serverKey testing"
print type(serverKey)
print len(str(serverKey))
if inital_setup == "0":
  a.set_sessionkey(sessionkey)
else:
  print "setting serverSessionKey"
  a.set_sessionkey(serverKey)

a.setupAES()

print "---------AES KEY--------------"
print a.get_key()

def recv():
    while True:
        data = client.recv(1024)
        if not data: sys.exit(0)
        print ""
        print "Recv Encypted Broadcast:", data
        data = a.dec_str(data)
        type(data)
        print "Decyping:", data

Thread(target=recv).start()

while True:
    data = raw_input('> ')
    if not data: break
    client.send(data)



print "Client Shutdown"
socket.Close(20000)






